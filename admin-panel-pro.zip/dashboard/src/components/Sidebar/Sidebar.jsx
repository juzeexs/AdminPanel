import { LayoutDashboard, Users, ShoppingCart, BarChart3, Settings, Bell, FileText, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import styles from './Sidebar.module.css';

const NAV_ITEMS = [
  {
    section: 'Principal',
    items: [
      { icon: LayoutDashboard, label: 'Dashboard', id: 'dashboard' },
      { icon: BarChart3, label: 'Analytics', id: 'analytics' },
      { icon: Bell, label: 'Notificações', id: 'notifications', badge: '5' },
    ]
  },
  {
    section: 'Gerenciar',
    items: [
      { icon: Users, label: 'Usuários', id: 'users' },
      { icon: ShoppingCart, label: 'Pedidos', id: 'orders' },
      { icon: FileText, label: 'Relatórios', id: 'reports' },
    ]
  },
  {
    section: 'Sistema',
    items: [
      { icon: Settings, label: 'Configurações', id: 'settings' },
    ]
  }
];

export default function Sidebar({ activePage, onNavigate, isOpen, onClose }) {
  const { user, logout } = useAuth();

  return (
    <>
      {isOpen && <div className={styles.overlay} onClick={onClose} />}
      <aside className={`${styles.sidebar} ${isOpen ? styles.open : ''}`}>
        <div className={styles.brand}>
          <div className={styles.brandIcon}>A</div>
          <span className={styles.brandName}>AdminPanel</span>
        </div>

        <nav className={styles.nav}>
          {NAV_ITEMS.map(section => (
            <div key={section.section} className={styles.navSection}>
              <div className={styles.navSectionLabel}>{section.section}</div>
              {section.items.map(item => (
                <button
                  key={item.id}
                  className={`${styles.navItem} ${activePage === item.id ? styles.active : ''}`}
                  onClick={() => { onNavigate(item.id); onClose(); }}
                >
                  <span className={styles.navIcon}><item.icon size={16} /></span>
                  {item.label}
                  {item.badge && <span className={styles.badge}>{item.badge}</span>}
                </button>
              ))}
            </div>
          ))}
        </nav>

        <div className={styles.footer}>
          <div className={styles.userCard}>
            <div className={styles.avatar}>{user?.avatar}</div>
            <div className={styles.userInfo}>
              <div className={styles.userName}>{user?.name}</div>
              <div className={styles.userRole}>{user?.role}</div>
            </div>
          </div>
          <button className={styles.logoutBtn} onClick={logout}>
            <LogOut size={16} />
            Sair
          </button>
        </div>
      </aside>
    </>
  );
}

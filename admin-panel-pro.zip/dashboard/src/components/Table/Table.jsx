import styles from './Table.module.css';

const ORDERS = [
  { id: '#8821', date: '21 Mar 2025', customer: 'Ana Rodrigues', avatar: 'AR', color: '#e8521a', product: 'MacBook Pro 14"', amount: 'R$12.499', status: 'completed' },
  { id: '#8820', date: '21 Mar 2025', customer: 'Carlos Lima', avatar: 'CL', color: '#1a5ce8', product: 'iPhone 15 Pro', amount: 'R$7.299', status: 'pending' },
  { id: '#8819', date: '20 Mar 2025', customer: 'Mariana Costa', avatar: 'MC', color: '#16a34a', product: 'AirPods Pro', amount: 'R$2.199', status: 'completed' },
  { id: '#8818', date: '20 Mar 2025', customer: 'Rafael Souza', avatar: 'RS', color: '#ca8a04', product: 'iPad Air', amount: 'R$5.499', status: 'canceled' },
  { id: '#8817', date: '19 Mar 2025', customer: 'Juliana Alves', avatar: 'JA', color: '#7c3aed', product: 'Apple Watch S9', amount: 'R$3.799', status: 'completed' },
  { id: '#8816', date: '19 Mar 2025', customer: 'Pedro Mendes', avatar: 'PM', color: '#0891b2', product: 'Samsung 4K TV', amount: 'R$4.899', status: 'pending' },
];

const STATUS_LABEL = {
  completed: 'Concluído',
  pending: 'Pendente',
  canceled: 'Cancelado',
};

export default function Table() {
  return (
    <div className={styles.card}>
      <div className={styles.cardHeader}>
        <div>
          <div className={styles.cardTitle}>Pedidos Recentes</div>
          <div className={styles.cardSubtitle}>Últimas 6 transações</div>
        </div>
        <button className={styles.viewAll}>Ver todos</button>
      </div>

      <div className={styles.tableWrap}>
        <table>
          <thead>
            <tr>
              <th>Pedido</th>
              <th>Cliente</th>
              <th>Produto</th>
              <th>Valor</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {ORDERS.map(order => (
              <tr key={order.id}>
                <td>
                  <div className={styles.orderCell}>
                    <span className={styles.orderId}>{order.id}</span>
                    <span className={styles.orderDate}>{order.date}</span>
                  </div>
                </td>
                <td>
                  <div className={styles.customerCell}>
                    <div className={styles.avatar} style={{ background: order.color }}>
                      {order.avatar}
                    </div>
                    <span className={styles.customerName}>{order.customer}</span>
                  </div>
                </td>
                <td style={{ color: 'var(--text-secondary)' }}>{order.product}</td>
                <td><span className={styles.amount}>{order.amount}</span></td>
                <td>
                  <span className={`${styles.status} ${styles[order.status]}`}>
                    <span className={styles.statusDot} />
                    {STATUS_LABEL[order.status]}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

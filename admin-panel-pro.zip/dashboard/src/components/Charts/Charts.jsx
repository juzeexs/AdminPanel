import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';
import styles from './Charts.module.css';

const areaData = [
  { name: 'Jan', receita: 42000, pedidos: 2100 },
  { name: 'Fev', receita: 53000, pedidos: 2800 },
  { name: 'Mar', receita: 48000, pedidos: 2400 },
  { name: 'Abr', receita: 61000, pedidos: 3100 },
  { name: 'Mai', receita: 55000, pedidos: 2700 },
  { name: 'Jun', receita: 72000, pedidos: 3600 },
  { name: 'Jul', receita: 68000, pedidos: 3400 },
  { name: 'Ago', receita: 84200, pedidos: 4100 },
];

const donutData = [
  { name: 'Eletrônicos', value: 38, color: '#e8521a' },
  { name: 'Roupas', value: 27, color: '#1a5ce8' },
  { name: 'Casa & Jardim', value: 20, color: '#16a34a' },
  { name: 'Outros', value: 15, color: '#ca8a04' },
];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border)',
        borderRadius: '10px',
        padding: '12px 16px',
        boxShadow: 'var(--shadow-md)',
        fontSize: '13px',
      }}>
        <p style={{ fontWeight: 700, marginBottom: 6, color: 'var(--text-primary)' }}>{label}</p>
        {payload.map(p => (
          <p key={p.dataKey} style={{ color: p.color, marginBottom: 2 }}>
            {p.dataKey === 'receita' ? 'Receita: R$' : 'Pedidos: '}
            {p.dataKey === 'receita' ? (p.value / 1000).toFixed(0) + 'k' : p.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function Charts() {
  const total = donutData.reduce((s, d) => s + d.value, 0);

  return (
    <div className={styles.grid}>
      {/* Area Chart */}
      <div className={styles.card}>
        <div className={styles.cardHeader}>
          <div>
            <div className={styles.cardTitle}>Receita & Pedidos</div>
            <div className={styles.cardSubtitle}>Últimos 8 meses</div>
          </div>
          <span className={styles.badge}>+12.5% este mês</span>
        </div>
        <div className={styles.chartWrap}>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={areaData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorReceita" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#e8521a" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#e8521a" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorPedidos" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#1a5ce8" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#1a5ce8" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="receita" stroke="#e8521a" strokeWidth={2} fill="url(#colorReceita)" dot={false} />
              <Area type="monotone" dataKey="pedidos" stroke="#1a5ce8" strokeWidth={2} fill="url(#colorPedidos)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Donut */}
      <div className={styles.card}>
        <div className={styles.cardHeader}>
          <div>
            <div className={styles.cardTitle}>Categorias</div>
            <div className={styles.cardSubtitle}>Distribuição de vendas</div>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={160}>
          <PieChart>
            <Pie
              data={donutData}
              cx="50%"
              cy="50%"
              innerRadius={48}
              outerRadius={72}
              paddingAngle={3}
              dataKey="value"
              strokeWidth={0}
            >
              {donutData.map((entry, i) => (
                <Cell key={i} fill={entry.color} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className={styles.legend}>
          {donutData.map(d => (
            <div key={d.name} className={styles.legendItem}>
              <span className={styles.legendDot} style={{ background: d.color }} />
              <span className={styles.legendLabel}>{d.name}</span>
              <span className={styles.legendPercent}>{d.value}%</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Mail, Lock, Eye, EyeOff, AlertCircle, Sun, Moon, ArrowRight } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import styles from './Login.module.css';

export default function Login() {
  const { login, loading, error, setError } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Preencha todos os campos.');
      return;
    }
    await login(email, password);
  };

  return (
    <div className={styles.container}>
      {/* Left Panel */}
      <div className={styles.left}>
        <div className={styles.leftBg} />
        <div className={styles.leftGrid} />

        <div className={styles.brand}>
          <div className={styles.brandIcon}>A</div>
          <span className={styles.brandName}>AdminPanel Pro</span>
        </div>

        <div className={styles.heroText}>
          <h1>
            Gerencie tudo<br />
            em um só <span>lugar.</span>
          </h1>
          <p>
            Plataforma completa de administração com analytics em tempo real,
            gestão de usuários e relatórios avançados.
          </p>
        </div>

        <div className={styles.stats}>
          <div className={styles.stat}>
            <span className={styles.statValue}>98%</span>
            <span className={styles.statLabel}>Uptime</span>
          </div>
          <div className={styles.stat}>
            <span className={styles.statValue}>12k+</span>
            <span className={styles.statLabel}>Usuários</span>
          </div>
          <div className={styles.stat}>
            <span className={styles.statValue}>4.9★</span>
            <span className={styles.statLabel}>Avaliação</span>
          </div>
        </div>
      </div>

      {/* Right Panel */}
      <div className={styles.right}>
        <button className={styles.themeToggle} onClick={toggleTheme} title="Alternar tema">
          {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
        </button>

        <div className={styles.formCard}>
          <div className={styles.formHeader}>
            <h2>Bem-vindo de volta.</h2>
            <p>Entre com suas credenciais para continuar.</p>
          </div>

          <div className={styles.demoHint}>
            <strong>👤 Credenciais de demonstração</strong>
            admin@panel.com · admin123
          </div>

          <form className={styles.form} onSubmit={handleSubmit}>
            <div className={styles.fieldGroup}>
              <label className={styles.label}>Email</label>
              <div className={styles.inputWrapper}>
                <span className={styles.inputIcon}><Mail size={16} /></span>
                <input
                  className={`${styles.input} ${error ? styles.inputError : ''}`}
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={e => { setEmail(e.target.value); setError(''); }}
                  autoComplete="email"
                />
              </div>
            </div>

            <div className={styles.fieldGroup}>
              <label className={styles.label}>Senha</label>
              <div className={styles.inputWrapper}>
                <span className={styles.inputIcon}><Lock size={16} /></span>
                <input
                  className={`${styles.input} ${error ? styles.inputError : ''}`}
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={password}
                  onChange={e => { setPassword(e.target.value); setError(''); }}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  className={styles.passwordToggle}
                  onClick={() => setShowPassword(s => !s)}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {error && (
              <div className={styles.errorMsg}>
                <AlertCircle size={15} />
                {error}
              </div>
            )}

            <button className={styles.submitBtn} type="submit" disabled={loading}>
              {loading ? (
                <>
                  <span className={styles.spinner} />
                  Entrando...
                </>
              ) : (
                <>
                  Entrar
                  <ArrowRight size={18} />
                </>
              )}
            </button>
          </form>

          <div className={styles.footer}>
            AdminPanel Pro © 2025 · Todos os direitos reservados
          </div>
        </div>
      </div>
    </div>
  );
}

import { DollarSign, Users, ShoppingCart, TrendingUp, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import styles from './StatCards.module.css';

const CARDS = [
  {
    label: 'Receita Total',
    value: 'R$84.2k',
    icon: DollarSign,
    color: 'orange',
    change: '+12.5%',
    trend: 'up',
    changeLabel: 'vs. mês anterior',
  },
  {
    label: 'Usuários Ativos',
    value: '12,841',
    icon: Users,
    color: 'blue',
    change: '+8.2%',
    trend: 'up',
    changeLabel: 'vs. mês anterior',
  },
  {
    label: 'Pedidos',
    value: '3,297',
    icon: ShoppingCart,
    color: 'green',
    change: '-2.4%',
    trend: 'down',
    changeLabel: 'vs. mês anterior',
  },
  {
    label: 'Taxa de Conversão',
    value: '4.87%',
    icon: TrendingUp,
    color: 'yellow',
    change: '+0.6%',
    trend: 'up',
    changeLabel: 'vs. mês anterior',
  },
];

export default function StatCards() {
  return (
    <div className={styles.grid}>
      {CARDS.map(card => (
        <div key={card.label} className={styles.card}>
          <div className={styles.cardTop}>
            <span className={styles.label}>{card.label}</span>
            <div className={`${styles.iconWrap} ${styles[card.color]}`}>
              <card.icon size={18} />
            </div>
          </div>

          <div className={styles.value}>{card.value}</div>

          <div className={styles.cardBottom}>
            <span className={`${styles.change} ${styles[card.trend]}`}>
              {card.trend === 'up' ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
              {card.change}
            </span>
            <span className={styles.changeLabel}>{card.changeLabel}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

import { Bell, Sun, Moon, Search, Menu } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import styles from './Header.module.css';

const PAGE_TITLES = {
  dashboard: { title: 'Dashboard', subtitle: 'Visão geral do sistema' },
  analytics: { title: 'Analytics', subtitle: 'Métricas e performance' },
  notifications: { title: 'Notificações', subtitle: '5 novas mensagens' },
  users: { title: 'Usuários', subtitle: 'Gerenciamento de contas' },
  orders: { title: 'Pedidos', subtitle: 'Controle de transações' },
  reports: { title: 'Relatórios', subtitle: 'Dados exportáveis' },
  settings: { title: 'Configurações', subtitle: 'Preferências do sistema' },
};

export default function Header({ activePage, onMenuToggle }) {
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const pageInfo = PAGE_TITLES[activePage] || PAGE_TITLES.dashboard;

  return (
    <header className={styles.header}>
      <button className={styles.menuBtn} onClick={onMenuToggle}>
        <Menu size={18} />
      </button>

      <div className={styles.titleBlock}>
        <div className={styles.title}>{pageInfo.title}</div>
        <div className={styles.subtitle}>{pageInfo.subtitle}</div>
      </div>

      <div className={styles.actions}>
        <button className={styles.iconBtn} title="Buscar">
          <Search size={17} />
        </button>

        <button className={styles.iconBtn} title="Notificações">
          <Bell size={17} />
          <span className={styles.notifDot} />
        </button>

        <div className={styles.divider} />

        <button className={styles.themeBtn} onClick={toggleTheme} title="Alternar tema">
          {theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}
        </button>

        <div className={styles.avatar} title={user?.name}>
          {user?.avatar}
        </div>
      </div>
    </header>
  );
}

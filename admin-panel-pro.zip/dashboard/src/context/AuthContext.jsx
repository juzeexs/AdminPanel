import { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

const DEMO_USERS = [
  { email: 'admin@panel.com', password: 'admin123', name: 'Lucas Ferreira', role: 'Admin', avatar: 'LF' },
  { email: 'jose@senai.br', password: 'jose123', name: 'José Silva', role: 'Editor', avatar: 'JS' },
];

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('adminpanel-user');
    return saved ? JSON.parse(saved) : null;
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const login = async (email, password) => {
    setLoading(true);
    setError('');
    await new Promise(r => setTimeout(r, 1200));
    const found = DEMO_USERS.find(u => u.email === email && u.password === password);
    if (found) {
      const { password: _, ...safeUser } = found;
      setUser(safeUser);
      localStorage.setItem('adminpanel-user', JSON.stringify(safeUser));
      setLoading(false);
      return true;
    } else {
      setError('Email ou senha incorretos.');
      setLoading(false);
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('adminpanel-user');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading, error, setError }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
